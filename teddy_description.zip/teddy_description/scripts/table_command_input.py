#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def send_command():
    rospy.init_node('table_command_input', anonymous=True)
    command_pub = rospy.Publisher('/table_command', String, queue_size=10)
    rate = rospy.Rate(1)
    while not rospy.is_shutdown():
        table_number = input("Enter table number to navigate to: ")
        if table_number:
            command_pub.publish(table_number)
        rate.sleep()

if __name__ == '__main__':
    try:
        send_command()
    except rospy.ROSInterruptException:
        pass
