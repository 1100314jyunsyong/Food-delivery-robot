#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PoseStamped, Point
from std_msgs.msg import String
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

class RestaurantBot:
    def __init__(self):
        rospy.init_node('restaurant_bot', anonymous=True)
        self.goal_pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
        self.status_pub = rospy.Publisher('/robot_status', String, queue_size=10)
        self.command_sub = rospy.Subscriber('/table_command', String, self.navigate_to_table)
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()
        
        self.return_position = PoseStamped()
        self.return_position.header.frame_id = "map"
        self.return_position.pose.position.x = -4.442883491516113
        self.return_position.pose.position.y = 4.295793533325195
        self.return_position.pose.orientation.w = 1.0

        self.table_locations = {
            "1": Point(-0.33292609453201294, -1.5253205299377441, 0),
            "2": Point(-0.2911904454231262, -4.148341655731201, 0),
            "3": Point(-0.5132900476455688, -7.319447994232178, 0),
            "4": Point(-0.4999677538871765, -10.26823902130127, 0)
        }

        self.is_busy = False

    def navigate_to_table(self, msg):
        if self.is_busy:
            rospy.loginfo("Robot is busy, please wait...")
            return

        self.is_busy = True
        table_number = msg.data
        if table_number in self.table_locations:
            goal = MoveBaseGoal()
            goal.target_pose.header.frame_id = "map"
            goal.target_pose.header.stamp = rospy.Time.now()
            goal.target_pose.pose.position = self.table_locations[table_number]
            goal.target_pose.pose.orientation.w = 1.0

            self.client.send_goal(goal)
            self.client.wait_for_result()
            result = self.client.get_state()
            if result == actionlib.GoalStatus.SUCCEEDED:
                rospy.loginfo(f"Reached table {table_number}")
                self.status_pub.publish(f"Reached table {table_number}")
                self.status_pub.publish("Please pick up the meal")
                rospy.sleep(5)  # Wait for the customer to pick up the meal
                self.return_to_pickup()
            else:
                rospy.logwarn(f"Failed to reach table {table_number}")
                self.status_pub.publish("Table not found")
        self.is_busy = False

    def return_to_pickup(self):
        self.client.send_goal_and_wait(MoveBaseGoal(target_pose=self.return_position))
        rospy.loginfo("Reached delivery counter")
        self.status_pub.publish("Reached delivery counter")
        self.is_busy = False

if __name__ == '__main__':
    try:
        bot = RestaurantBot()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
